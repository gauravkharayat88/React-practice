import React from 'react'

const fp = () => {
    return (
        <div>
          <p className='group'> MetBlog</p> 
            <div className='welcome'>
  <p>Featured</p> 
  
</div>
        </div>
    )
}

export default fp
