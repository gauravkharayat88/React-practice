
import './App.css';
import Fp from './components/Fp'
import Carts from './components/Carts'
function App() {
  return (
    <>
      <div className="App">

    
      </div>

      <Fp />
      <Carts/>
    </>
  );
}

export default App;
