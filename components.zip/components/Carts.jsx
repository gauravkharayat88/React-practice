import React from 'react'
import img from './Images/img.png'
const Carts = () => {
  return (
    
    <div className='cart'>
     
 
        <div
        className='blank-box'>
             < img className='cart-01' src={img}></img>   
    
        <p
        className='diff'>Difficulty in assembling track</p>
        <p className='lorem'>lorem ipsum is simply a dummy text of <br/>the printing and typesetting industry</p>
      </div>
      <div className='cart-02'>
     
 
     <div
     className='blank-box'>
          < img className='cart-01' src={img}></img>   
 
     <p
     className='diff'>Difficulty in assembling track</p>
     <p className='lorem'>lorem ipsum is simply a dummy text of <br/>the printing and typesetting industry</p>
</div>
</div>
<div className='cart-03'>
<div
        className='blank-box'>
             < img className='cart-01' src={img}></img>   
    
        <p
        className='diff'>Difficulty in assembling track</p>
        <p className='lorem'>lorem ipsum is simply a dummy text of <br/>the printing and typesetting industry</p>
      </div>
      </div>
      <div className='cart-05'>
     
 
     <div
     className='blank-box'>
          < img className='cart-01' src={img}></img>   
 
     <p
     className='diff'>Difficulty in assembling track</p>
     <p className='lorem'>lorem ipsum is simply a dummy text of <br/>the printing and typesetting industry</p>
</div>
</div>
    </div>

  )
}

export default Carts
